// server/lib/constants.ts
export const DEFAULT_COMMISSION_RATE = 12.5;